import { getAllByPlaceholderText } from '@testing-library/dom';
import React, { useRef } from 'react';
import {useState} from 'react';
import Form from './Form';
import  './App.css';


const CourseItem=(props)=>
{  

    const [isformshown,setshowForm]=useState(false);

    const showForm=(e)=>
    {
        e.preventDefault();
        if(isformshown)
        {
            return;
        }
        else{
            setshowForm(true);
        }
        
    };
    const hideform=()=>
    {
        setshowForm(false);
    };
  
    return(
  <div>
   <div> 
   {!isformshown && <div className="parentdiv">     
        <div className="child1">
            <label>Course name</label>
            <p>{props.name}</p></div>
        <div className="child2"> 
            <label>Trainer name</label>
            <p>{props.trainer}</p></div>
        <button type="button" onClick={showForm}>Enquiry</button> 
        </div> 
}            
    </div>

    <div>
        {isformshown && <Form id={props.name} cancelform={hideform}></Form>} 
    </div>
    </div>


  );

}

export default CourseItem;