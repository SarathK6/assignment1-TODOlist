import React from 'react';
import {useState,useEffect}from 'react';
import CourseItem from './CourseItem';
import './App.css';

import { Link } from 'react-router-dom';

const initialData=[];
const Courses=()=>
{
const [list,SetList]=useState(initialData);
const [isFormShown,setFormShow]=useState(false);

useEffect(() => {
    fetch("http://localhost:3001/Courses")
    .then(response => response.json())
        // 4. Setting *dogImage* to the image url that we received from the response above
    .then(data => SetList(data))
  },[])

  return (
    <div className="App"> 
   
        <h1>Start Taking Courses </h1>
       
        {list.map(listitem => {
              return (
                  <CourseItem key={listitem.id} id={listitem.id} 
                  name={listitem.name} trainer={listitem.trainer}/>
              )
          })}      
  </div>
  )
}

export default Courses;