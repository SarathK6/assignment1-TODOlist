import { useState,useEffect} from "react";
import './App.css';
import './list.css';

const Enquiry=()=>
{

    const [list,SetList]=useState([]);
    
    
    useEffect(() => {
        fetch("http://localhost:3001/Enquiry")
        .then(response => response.json())
         // 4. Setting *dogImage* to the image url that we received from the response above
        .then(data => SetList(data))
      },[])
    
      return (
        <div> 
       
            <h1>User Enquiries about Courses </h1>
           <ol>
            {list.map(listitem => {
                  return (
                      <li key={listitem.id}>{listitem.query} asked by User {listitem.email}</li>
                  )
              })}
            </ol>      
      </div>
      )

}

export default Enquiry;