import logo from './logo.svg';
import './App.css';
import Courses  from './Courses';
import {
  BrowserRouter,
  Routes,
  Route,
  Link
} from "react-router-dom";
import Enquiry  from './Enquiry';

function App() {
  return (

    <BrowserRouter>
    <div className="topnav"> 
      <a href="/">Courses</a>
      <a href="/Enquiry">Enquiry</a>
    </div>
    <div className="body"> 
      <Routes>
        <Route path="/" element={<Courses />} />
        <Route path="/Enquiry" element={<Enquiry />} />        
      </Routes>
      </div>
    </BrowserRouter>
    
        
  );
}

export default App;
