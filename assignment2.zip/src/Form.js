import { useState,useRef } from "react";
import './Form.css'

const Form=(props)=>
{

    const querytext=useRef();
    const emailref=useRef();

    function handleFormsubmit(event)
    {
        event.preventDefault();
        let query=querytext.current.value;
        let email=emailref.current.value;
        let data={email:email,query:query};

        fetch("http://localhost:3001/Enquiry",{  
            headers: {
                'Content-Type': 'application/json',
              },    
        method: 'POST',
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(result => {
      console.log('Success:', result);
    })
    .catch(error => {
      console.error('Error:', error);
    });

        querytext.current.value='';
        emailref.current.value='';
        props.cancelform();
    }

    function handleCancel()
    {
        props.cancelform();
    }

    return(

        <div className="container">
            <p>Please enter your query on {props.id}</p>
            <form onSubmit={handleFormsubmit}>
            <label>Query</label><input type="text" style={{"height":"200 px"}} ref={querytext} placeholder="please enter your query"></input>
        <label>Your Email address </label><input type="email" ref={emailref} placeholder="your email address"></input>
        <button type="submit">SUBMIT</button>
        <button type="cancel" onClick={handleCancel}>Cancel</button>
        </form>    
        
        
        </div>



    );



}
export default Form;